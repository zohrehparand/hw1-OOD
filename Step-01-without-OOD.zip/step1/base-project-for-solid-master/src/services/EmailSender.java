package services;

class EmailSender implements MessageSender{
    public void sendEmail(String to, String message){
        System.out.println("Sending email to " + to + ": " + message);
    }

    @Override
    public void sendSms(String to, String message) {
        throw new UnsupportedOperationException("Unimplemented method 'sendSms'");
    }
}
