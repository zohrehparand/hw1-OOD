package services;

public class SmsSender implements MessageSender{
    public void sendSms(String to, String message){
        System.out.println("Sending sms to " + to + ": " + message);
    }

    @Override
    public void sendEmail(String to, String message) {
        throw new UnsupportedOperationException("Unimplemented method 'sendEmail'");
    }
}
