package constants;

public enum Notifier {
    EMAIL,SMS
}
