package constants;

public enum PaymentMethods {
    PAYPAL,CARD,CASH,ONSITE
}
