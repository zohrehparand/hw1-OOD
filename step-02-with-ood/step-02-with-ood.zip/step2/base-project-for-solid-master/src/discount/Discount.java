package discount;

public interface Discount {

}
