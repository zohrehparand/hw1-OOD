package invoice;

import services.Reservation;

public class Invoiceservice {
    public void printInvoice(Reservation res){
        System.out.println("----- INVOICE -----");
        System.out.println("Customer: " + res.getCustomerName());
        System.out.println("Room: " + res.getRoom().getNumber() + " (" + res.getRoom().getType() + ")");
        System.out.println("Total: " + res.totalPrice());
        System.out.println("-------------------");
    }
}