
package notify;

import services.Reservation;

public class Emailnotifier implements Notifierservice {
    public void notifier(Reservation res) {
        System.out.println("Sending email to " 
            + res.getCustomer().getEmail() 
            + ": Your reservation confirmed!");
    }
}

