package notify;

import services.Reservation;

public interface Notifierservice {
void notifier(Reservation res);
}
