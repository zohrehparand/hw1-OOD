package notify;

import services.Reservation;

public class Smsnotifier implements Notifierservice {
    public void notifier(Reservation res) {
        System.out.println("Sending SMS to " 
            + res.getCustomer().getMobile() 
            + ": Your reservation confirmed!");
    }
}

