package payment;

import services.Reservation;

public class OnSitePayment implements PaymentService {
    public void OnSitePayment(double amount){ System.out.println("on site payment: " + amount); }
    public void paymentcalculate(Reservation res){

                OnSitePayment(res.totalPrice());
    }
}
