package payment;

import services.Reservation;

public interface PaymentService {
    void paymentcalculate(Reservation res);
}
