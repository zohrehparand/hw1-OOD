package payment;

import services.Reservation;

public class payByCash implements PaymentService {
    public void payByCash(double amount){ System.out.println("Paid by cash: " + amount); }
    public void paymentcalculate(Reservation res){

                payByCash(res.totalPrice());
    }
}
