package payment;

import services.Reservation;

public class payByPayPal implements PaymentService {
    public void payByPayPal(double amount){ System.out.println("Paid by PayPal: " + amount); }
    public void paymentcalculate(Reservation res){

                payByPayPal(res.totalPrice());
    }
}
