package payment;

import services.Reservation;

public class paybycard implements PaymentService{
    public void payByCard(double amount){ System.out.println("Paid by card: " + amount); }
    public void paymentcalculate(Reservation res){
            payByCard(res.totalPrice());
 
        }
}
