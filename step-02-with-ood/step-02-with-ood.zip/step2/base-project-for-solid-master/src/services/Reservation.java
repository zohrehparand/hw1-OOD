package services;

import models.Customer;
import models.Room;

public class Reservation {
    private Customer customer;
    private Room room;
    private int nights;

    public Reservation(Room r, Customer c, int nights) {
        this.room = r;
        this.customer = c;
        this.nights = nights;
    }

    public Customer getCustomer(){ return customer; }
    public Room getRoom(){ return room; }

    public String getCustomerName(){ return customer.getName(); }
    public String getCustomerEmail(){ return customer.getEmail(); }

    public double getRoomPrice(){ return room.getPrice(); }
    public void setRoomPrice(double price){ room.setPrice(price); }

    public int getNights(){ return nights; }
    public void setNights(int nights){ this.nights = nights; }

    public double totalPrice(){ return room.getPrice() * nights; }
}