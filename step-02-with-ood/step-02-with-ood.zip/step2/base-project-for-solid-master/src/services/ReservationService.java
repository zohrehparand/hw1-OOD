package services;

import constants.Notifier;
import constants.PaymentMethods;
import discount.Citydiscount;
import invoice.Invoiceservice;
import notify.Emailnotifier;
import payment.paybycard;

public class ReservationService {
    private paybycard paymentService;
    private Invoiceservice invoiceService;
    private Emailnotifier notifierService;
    private Citydiscount discount;

    public ReservationService() {
        this.paymentService = paymentService;
        this.invoiceService = invoiceService;
        this.notifierService = notifierService;
        this.discount = discount;
    }

    public void makeReservation(Reservation res, PaymentMethods paymentType, Notifier notifier) {
        System.out.println("Processing reservation for " + res.getCustomerName());

        double discountedPrice = discount.applyDiscount(res);
        res.setRoomPrice(discountedPrice);

        paymentService.paymentcalculate(res);
        invoiceService.printInvoice(res);
        notifierService.notifier(res);
    }
}